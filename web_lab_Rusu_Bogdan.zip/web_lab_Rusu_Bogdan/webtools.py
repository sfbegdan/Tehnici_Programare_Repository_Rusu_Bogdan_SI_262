# Laborator: funcții, metode și importuri pe web
# Student: Rusu Bogdan
from bs4 import BeautifulSoup

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import requests, socket, ssl, time, urllib, urllib.parse, json

DEFAULT_HEADERS = {"User-Agent": "WebLab-Rusu Bogdan"}

def fetch(url: str, timeout=10):
    response = requests.get(url, timeout=TIMEOUT, headers=DEFAULT_HEADERS)
    print(response.status_code)
    return response

def get_status(url: str) -> int:
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code

def get_title(html: str) -> str:
    """
    aceasta functie extrage titlul unui site
    """

    start = html.find("<title>") + len("<title>") + 2
    end = html.find("</title>") - 3

    title_raw = html[start:end]
    title = title_raw.strip()

    return title

def security_headers(url):
    response = requests.get(url, timeout=TIMEOUT)
    header_verific = {"Strict-Transport_Security", "Content-Security-Policy", "X-Frame-Options",
                      "X-Content-Type-Options", "Referrer-Policy"}

    result = {}

    for header in header_verific:
        result[header] = header in response.headers
    return result


if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))

#redirectinoare

def redirect(url):
    response = requests.get(url, timeout=TIMEOUT)
    lista = []
    if response.history:
        for resp in response.history:
            lista.append(resp.url)
        lista.append(response.url)
    return lista

def security_headers(url):
    response = requests.get(url, timeout=TIMEOUT)
    header_verific = {"Strict-Transport_Security", "Content-Security-Policy", "X-Frame-Options",
                      "X-Content-Type-Options", "Referrer-Policy"}

    result = {}

    for header in header_verific:
        result[header] = header in response.headers
    return result

def score_headers(results):
    bun = 0
    rau = 0
    for header in results:
        if(results[header] is True):
            bun += 1
        elif(results[header] is False):
            rau += 1
    ambele = bun + rau
    return f"{bun}/{ambele}"

def resolve(hostname):
    return socket.gethostbyname(hostname)

def cert_days_left(hostname):
    context = ssl.create_default_context()

    with socket.create_connection((hostname, 443)) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
            not_after = cert["notAfter"]

            exp_seconds = ssl.cert_time_to_seconds(not_after)
            current_seconds = time.time()

            diferenta_secunde = exp_seconds - current_seconds
            zile_ramase = diferenta_secunde / (60 * 60 * 24)

            return int(zile_ramase)

def split_links(domain):
    link_intern = []
    link_extern = []

    response = requests.get(domain, timeout=TIMEOUT)
    soup = BeautifulSoup(response.text, "html.parser")

    domeniu_baza = urllib.parse.urlparse(domain).netloc

    for link in soup.find_all("a", href=True):
        url_complet = urllib.parse.urljoin(domain, link["href"])
        netloc_link = urllib.parse.urlparse(url_complet).netloc

        if netloc_link == domeniu_baza:
            link_intern.append(link["href"])
        else:
            link_extern.append(link["href"])

    return link_intern, link_extern

def fetch_robots(base):
    url = base.rstrip("/") + "/robots.txt"

    try:
        response = requests.get(url, timeout=TIMEOUT)
        if (response.status_code == 200):
            return response.text
    except requests.RequestException:
        return None

def disallowed_paths(robots_text: str | None = None) -> list:
    paths = []

    if robots_text is None:
        return paths

    for line in robots_text.splitlines():
        line = line.strip()
        if line.lower().startswith("disallow:"):
            path = line.split(":", 1)[1].strip()
            paths.append(path)
    return paths


#ex50
print("------ex50------")

def site_report(url):
    print(f"Codul de stare: {get_status(url)}")
    print(f"Titlu: {get_title(url)}")
    link = BASE_URL.lstrip("https://")
    print(f"IP adress: {resolve(link)}")
    print(f"lista redirectionarilor: {redirect(url)}")
    print(f"Scor securitate: {score_headers(security_headers(url))}")
    print(f"Zile pana la expirare: {cert_days_left(link)}")
    interne, externe = split_links(url)
    print(f"interne: {interne}, externe: {externe}")
    print(f"cai interzise: {disallowed_paths(url)}")

    data = [get_status(url), get_title(url), resolve(link), redirect(url),
            score_headers(security_headers(url)), cert_days_left(link), interne, externe,
            disallowed_paths(url)]

    with open("report.json", "w", encoding="utf-8") as file:
        json.dump(data, file, indent=2)



site_report(BASE_URL)