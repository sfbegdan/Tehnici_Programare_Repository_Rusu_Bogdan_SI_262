# Laborator: funcții, metode și importuri pe web
# Student: Rusu Bogdan
from operator import truediv

import requests
import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

#ex21
print("------ex21------")

def fetch(url: str, timeout=10):
    """printeaza si returneaza response status code"""
    response = requests.get(url, timeout=TIMEOUT)
    print(response.status_code)
    return response

fetch(BASE_URL)

#ex22
print("------ex22------")

def get_status(url: str) -> int:
    """returneaza response status code"""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code

print(get_status(BASE_URL + "/robots.txt"))
time.sleep(1)
print(get_status(BASE_URL + "/sitemap.xml"))

#ex23
print("------ex23------")

fetch(BASE_URL)
fetch(BASE_URL, timeout=3)

#ex24
print("------ex24------")

def get_title(html: str) -> str:
    """
    aceasta functie extrage titlul unui site
    """

    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")

    title_raw = html[start:end]
    title = title_raw.strip()

    return title

print(get_title(BASE_URL))

#ex25
print("------ex25------")

help(get_title)

#ex26
print("------ex26------")

print("am pus")

#ex27
print("------ex27------")

def page_exists(url):
    """returneaza true sau false daca exista pagina"""
    try:
        response = requests.get(url, timeout=TIMEOUT)
        return True
    except requests.RequestException:
        return False

print(page_exists(BASE_URL))
print(page_exists("https://this-domain-does-not-exist.invalid"))

#ex28
print("------ex28------")

def check_paths(base, paths):
    """returneaza un dictionar ce contine path-urile care exista si status code-ul lor"""
    dictionar = {}
    for path in paths:
        url = base.rstrip("/") + "/" + path.rstrip("/")

        response = requests.get(url, timeout=TIMEOUT)
        dictionar[path] = response.status_code
    return dictionar

print(check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"] ))

#ex29
print("------ex29------")

def get_header(url, name, default="lipseste"):
    """returneaza header-ul numit la chemarea functiei"""
    response = requests.get(url, timeout=TIMEOUT)
    if name in response.headers:
        return response.headers[name]
    else:
        return default

print(get_header(BASE_URL, name="Server"))

#ex30
print("------ex30------")

def security_headers(url):
    """returneaza care security headers sunt prezente"""
    response = requests.get(url, timeout=TIMEOUT)
    header_verific = {"Strict-Transport_Security", "Content-Security-Policy", "X-Frame-Options",
                      "X-Content-Type-Options", "Referrer-Policy"}

    result = {}

    for header in header_verific:
        result[header] = header in response.headers
    return result

print(security_headers(BASE_URL))

#ex31
print("------ex31------")

def score_headers(results):
    """returneaza scorul de security headers care sunt prezente"""
    bun = 0
    rau = 0
    for header in results:
        if(results[header] is True):
            bun += 1
        elif(results[header] is False):
            rau += 1
    ambele = bun + rau
    return f"{bun}/{ambele}"

print(score_headers(security_headers(BASE_URL)))

#ex32
print("------ex32------")

def fetch_robots(base):
    """returneaza textul fisierului robots.txt"""
    url = base.rstrip("/") + "/robots.txt"

    try:
        response = requests.get(url, timeout=TIMEOUT)
        if (response.status_code == 200):
            return response.text
    except requests.RequestException:
        return None

print(fetch_robots(BASE_URL))

def disallowed_paths(robots_text: str | None = None) -> list:
    """returneaza o lista cu toate valorile disallowed"""
    paths = []

    if robots_text is None:
        return paths

    for line in robots_text.splitlines():
        line = line.strip()
        if line.lower().startswith("disallow:"):
            path = line.split(":", 1)[1].strip()
            paths.append(path)
    return paths

print(disallowed_paths(BASE_URL))
print(disallowed_paths())

#ex33
print("------ex33------")

def response_times(*urls):
    """returneaza dictionar care arata cate secunde a durat sa se incarce site-ul"""
    rezultate = {}
    for url in urls:
        try:
            response = requests.get(url, timeout=TIMEOUT)
            rezultate[url] = response.elapsed.total_seconds()
        except requests.RequestException:
            rezultate[url] = None
    return rezultate

print(response_times(BASE_URL))
print(response_times("https://youtube.com"))

#ex34
print("------ex34------")

def log(message, **details):
    """afiseaza mesajul urmat de fiecare detaliu"""
    parts = [message]

    for key, value in details.items():
        parts.append(f"{key}={value}")
    print(" | ".join(parts))

print(log("verificat", url=BASE_URL, status=200))