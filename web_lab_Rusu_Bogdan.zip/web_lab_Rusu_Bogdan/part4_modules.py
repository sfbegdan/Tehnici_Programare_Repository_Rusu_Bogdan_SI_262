# Laborator: funcții, metode și importuri pe web
# Student: Rusu Bogdan

import urllib.parse
import re
import requests
import hashlib
import json
import socket
import ssl
import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

#ex35
print("------ex35------")

parsed_url = urllib.parse.urlparse("https://cybercor.org/path?x=1#top")

print("Scheme:", parsed_url.scheme)
print("Netloc:", parsed_url.netloc)
print("Path:", parsed_url.path)
print("Query:", parsed_url.query)
print("Fragment:", parsed_url.fragment)

#ex36

print("------ex36------")

print(urllib.parse.urljoin(BASE_URL, "/about"))
print(urllib.parse.urljoin(BASE_URL, "contact.html"))
print(urllib.parse.urljoin(BASE_URL, "../index.html"))

#ex37
print("------ex37------")

def extract_links(html):
    """returneaza toate legaturile de pe pagina principala fara duplicate"""
    response = requests.get(html)

    linkuri = re.findall(r'href="([^"]+)"', response.text)
    linkuri_unicale = list(set(linkuri))
    return linkuri_unicale

print(extract_links(BASE_URL))

#ex38
print("------ex38------")

def split_links(links, domain):
    """returneaza legaturile de pe acelasi domeniu si legaturile catre alte site-uri"""
    link_intern = []
    link_extern = []

    domeniu_baza = urllib.parse.urlparse(domain).netloc

    for link in links:
        url_complet = urllib.parse.urljoin(domain, link)
        netloc_link = urllib.parse.urlparse(url_complet).netloc

        if netloc_link == domeniu_baza:
            link_intern.append(link)
        else:
            link_extern.append(link)

    return link_intern, link_extern

lista_linkuri = [
    "contact.html",
    "/despre",
    "https://example.com/produse",
    "https://google.com",
    "https://github.com/python"
]

print(split_links(lista_linkuri, "https://example.com/blog/"))

#ex39
print("------ex39------")

from html.parser import HTMLParser

class ImageFinder(HTMLParser):
    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        if tag == "img":
            src = dict(attrs).get("src")
            if src:
                self.images.append(src)
        pass


test_html = """
<html><body>
  <img src="/logo.png" alt="Logo">
  <IMG SRC="poza.jpg">
  <img alt="imagine fără src">
  <img src="https://cdn.example.com/banner.webp" />
  <a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""

finder = ImageFinder()
finder.feed(test_html)
print(finder.images)

assert finder.images == [
    "/logo.png",  # imagine obișnuită
    "poza.jpg",  # tag scris cu majuscule
    "https://cdn.example.com/banner.webp",  # tag care se închide singur
], "Parserul nu a găsit exact imaginile așteptate"
print("Testul a trecut!")

response = requests.get(BASE_URL, timeout=TIMEOUT)
finder = ImageFinder()
finder.feed(response.text)
print(len(finder.images), "imagini găsite")
for src in finder.images:
    print(src)

print(response.text.lower().count("<img"))
print("m-am uitat in browser si cybercor nu are imagine salvate cu tag <img>")

#ex40
print("------ex40------")

def page_fingerprint(url):
    """returneaza hash256 a paginii"""
    response = requests.get(url)
    return hashlib.sha256(response.content).hexdigest()

print(page_fingerprint(BASE_URL))
print(page_fingerprint(BASE_URL))
print(page_fingerprint("https://example.com"))
print(page_fingerprint("https://example.com/blog/"))

#hash-urile ar fi diferite daca schimbam pagina, daca continutul paginii s-a modificat,
#daca pagina contine elemente dinamice si daca pagina se schimba bazat pe user id

#ex41
print("------ex41------")

response = requests.get(BASE_URL, timeout=TIMEOUT)

with open("headers.json", "w", encoding="utf-8") as file:
    json.dump(dict(response.headers), file, indent=2)

with open("headers.json", "r", encoding="utf-8") as file:
    loaded_headers = json.load(file)

print("Un antet din fisier (Content-Type):", loaded_headers.get("Content-Type"))

#ex42
print("------ex42------")

def resolve(hostname):
    """returneaza adresa ip a site-ului"""
    return socket.gethostbyname(hostname)

print(resolve("cybercor.org"))

#ex43
print("------ex43------")

def cert_days_left(hostname):
    """returneaza cate zile mai are domain-ul pana expira certificatul"""
    context = ssl.create_default_context()

    with socket.create_connection((hostname, 443)) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
            not_after = cert["notAfter"]

            exp_seconds = ssl.cert_time_to_seconds(not_after)
            current_seconds = time.time()

            diferenta_secunde = exp_seconds - current_seconds
            zile_ramase = diferenta_secunde / (60 * 60 * 24)

            return int(zile_ramase)

print(cert_days_left("cybercor.org"))

