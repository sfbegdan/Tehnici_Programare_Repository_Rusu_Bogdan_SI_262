# Laborator: funcții, metode și importuri pe web
# Student: Rusu Bogdan

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

#ex44
print("------ex44------")

import webtools

webtools.get_title(webtools.fetch(BASE_URL).text)

#ex45

from webtools import get_title, security_headers

#daca as scrie get_title, functia din main ar suprapune si ar fi primara
#fata de cea din webtools

#ex46
#cand rulez webtools.py, se seteaza variabila speciala __name__ la __main__, pe cand,
#cand rulez main si importez from webtools, variabila speciala __name__ se seteaza la
#numele fileului, adica webtools si autotest este ignorat.

#ex47
print("------ex47------")

from webtools import DEFAULT_HEADERS
print(DEFAULT_HEADERS)

#ex48
import argparse

parser = argparse.ArgumentParser(description="Extrage titlul unei pagini web.")

parser.add_argument("url", type=str, help="URL-ul paginii web care va fi analizată")

args = parser.parse_args()

response = webtools.fetch(args.url)
if response:
    title = get_title(response.text)
    print("Titlul paginii:", title)

#ex49
import csv
from datetime import datetime
from part3_functions import check_paths

results = check_paths()

with open("report.csv", mode="w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)

    writer.writerow(["path", "status", "checked_at"])

    now_iso = datetime.now().isoformat()

    for path, status in results:
        writer.writerow([path, status, now_iso])

print("raportul csv a fost salvat cu succes în report.csv")







