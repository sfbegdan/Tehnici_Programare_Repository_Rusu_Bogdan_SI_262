# Laborator: funcții, metode și importuri pe web
# Student: Rusu Bogdan
from asyncio import timeout

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

#ex9
print("------ex9------")

import requests

response = requests.get(BASE_URL, timeout=TIMEOUT)
print(response.status_code) # atribut
print(response.ok) # atribut
print(response.url) # atribut
print(response.encoding) # atribut

#ex10
print("------ex10------")

try:
    response = requests.get(BASE_URL, timeout=TIMEOUT)
    response.raise_for_status()
    print("Accesat pagina principală cu success")
except requests.HTTPError:
    print("Eroare HTTP pe pagina principală")

try:
    response = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
    response.raise_for_status()
    print("Cumva ai accesat pagina care nu ar trebuii sa existe")
except requests.HTTPError:
    print("Pagina aceasta nu există")

#ex11
print("------ex11------")

response = requests.get(BASE_URL, timeout=TIMEOUT)

for Nume, Valoare in response.headers.items():
    print(f"{Nume}: {Valoare}")

#ex12
print("------ex12------")

print(response.headers.get("Serverul", "lipsește"))
print(response.headers.get("Content-Type", "lipsește"))

print(response.headers.get("content_type", "lipsește"))
# Observăm că HTTP tratează numele antetelor ca fiind case-insensitive

#ex13
print("------ex13------")

response = requests.get(BASE_URL, timeout=TIMEOUT)
print(response.text.lower().count("cyber"))
# putem înlănțuii lower și count, deoarece lower returnează un string
# cu toate literele transformate in minusculă, după care putem chema count
# fix pe acest string, folosind înlănțuirea

#ex14
print("------ex14------")

response = requests.get(BASE_URL, timeout=TIMEOUT)

start = response.text.find("<title>") + len("<title>")
end = response.text.find("</title>")

title_raw = response.text[start:end]
title = title_raw.strip()

print(title)

#ex15
print("------ex15------")

response = requests.get(BASE_URL, timeout=TIMEOUT)

lines = response.text.splitlines()
numar_linii = len(lines)
print(f"Sunt: {numar_linii} linii")
cea_mai_lunga = max(lines, key=len)
lungime_maxima = len(cea_mai_lunga)
print(f"Lungimea maxima este: {lungime_maxima}")

#ex16
print("------ex16------")

response = requests.get(BASE_URL, timeout=TIMEOUT)

if response.url.startswith("https://"):
    print("Conexiune securizata")
else:
    print("Conexiune nesecurizata")

#ex17
print("------ex17------")

response = requests.get("http://cybercor.org", timeout=TIMEOUT)

for r in response.history:
    print(f"Code de stare: {r.status_code} | URL: {r.url}")
print(f"Code de stare final: {response.status_code} | URL: {response.url}")

#ex18
print("------ex18------")

respget = requests.get(BASE_URL, timeout=TIMEOUT)
resphead = requests.head(BASE_URL, timeout=TIMEOUT)

print(f"Lungimea GET: {len(respget.content)}")
print(f"Lungimea HEAD: {len(resphead.content)}")
#head cere doar headers si nu tot continutul codului site-ului

#ex19
print("------ex19------")

response = requests.get(BASE_URL,timeout=TIMEOUT)

if response.cookies:
    for cookie in response.cookies:
        print(f"Nume: {cookie.name}| Secure: {cookie.secure}")
else:
    print("Nici un cookie setat")

#20
print("------ex20------")

session = requests.session()
session.headers.update({"User-Agent": "WebLab-Rusu Bogdan"})
response = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
print(response.json())