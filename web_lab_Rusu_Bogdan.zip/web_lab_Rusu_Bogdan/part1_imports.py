# Laborator: funcții, metode și importuri pe web
# Student: Rusu Bogdan

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

#ex1
print("------ex1------")

import requests
print(requests.__version__)
import urllib.request

# urllib face parte din biblioteca standard Python, dar requests
# face parte dintr-o librarie externa

#ex2
print("------ex2------")

response = requests.get(BASE_URL, timeout=TIMEOUT)
print(response.status_code)

# Codul este clar si usor de intretinut in proiecte mari, deoarece
# namespace-ul ramane organizat. Oricine citeste codul stie imediat
# că functia `get` si celelalte metode apartin bibliotecii `requests`.

#ex3
print("------ex3------")

import requests as rq
response = rq.get(BASE_URL)
print(response.status_code)

# alias-urile fac codul mai usor cand biblioteca are nume foarte lungi
# si il fac mai greu cand alias-ul are un nume neconventional

#ex4
print("------ex4------")

headers = {'User-Agent': 'Mozilla/5.0'}
req = urllib.request.Request(BASE_URL, headers=headers)

with urllib.request.urlopen(req, timeout=TIMEOUT) as response:
    print('Cod de stare: ', response.status)
    body_preview = response.read().decode('utf-8')
    print('Primele 200 caractere: ')
    print(body_preview[:200])

#ex5
print("------ex5------")

print(dir(response))

# get - functie
# response - clasa
# exceptions - modul

#ex6
print("------ex6------")

help(requests.get)
response = requests.get(BASE_URL, timeout=TIMEOUT)
print(response.status_code)

#ex7
print("------ex7------")

import time

start_time = time.perf_counter()
response = requests.get(BASE_URL, timeout=TIMEOUT)
end_time = time.perf_counter()
perf_duration = end_time - start_time
elapsed_duration = response.elapsed.total_seconds()
print(f"Timpul cu time.perf_counter(): {perf_duration:.4f} secunde")
print(f"Timpul cu response.elapsed:     {elapsed_duration:.4f} secunde")
print(f"Diferența:                      {abs(perf_duration - elapsed_duration):.4f} secunde")

#ex8
print("------ex8------")

try:
    import bs4
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")